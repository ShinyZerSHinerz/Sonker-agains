# Changelog

Follow the latest changes on GitHub: https://github.com/fadeinside/s3air-extra-character-slots-unlimited

## Release v8.0 (2022.11.20) - Unlimited Release

Extra Character Slots has been updated to always be relevant to you. Meet - Unlimited release!

To finish this update, we needed to completely rewrite the framework. We were able to achieve what no one else could, namely to expand the number of available slots to create extra characters.

For a long time, up to version v7.35, you could create and select only 3 extra characters. Recently, this has become especially inconvenient, given the plans for the future of the *Extra Slot Zone* team, and with the advent of more modders creating their own characters. 

Therefore, iCloudius asked me to increase the available character slots to 8. It sounds like a joke, doesn't it? Starting from version v8.0, you can create and select to 255 unique characters with no restrictions.

-Fade

* Completely rewritten framework code base and new structure.
* Optimizations and improvements for stability.
* Fixed noticed bugs from the Legacy (v7.35) version.
* Range of extra characters that can be created has been increased from 3 to 255!
* Added support for spawning characters in the Best Ending screen.
* Added new menu to support extra characters in Act Select.
* Added integrated support with D.A. Garden Edition.
* Added build-in Discord RPC support (Only for PC).
* Added more extras for the renderhook.
* ..And not only this!