--------------
SAWNIC CREDITS
--------------
BLUΞ - Main developer, programmer, spriter, tester and the person writing all these names right now
iCloudius - VFX programming assistance and testing
SAWhane25 - General guidance and testing, also provided NP assets to use as reference for custom sprites
PixelsTay - General Guidance, also provided NP assets
Dynamic Lemons - Testing, Programming optimizations, compatibility, bug fixing, and code tweaks
LunarCryptik - Don't Panic, Scrappy Beat & Act Clear Jam Sonic 3 remixes
HazelSpooder - Programming assistance
Raf - Sawnic/Sludgeles sprites
Louplayer - Pink Burner & Monitor sprites and general sprite tweaks and fixes
-------------
OTHER CREDITS
-------------
PixelsTay - Newtrogic Panic lead
SAWhane25 - Newtrogic Panic co-lead
ScrewStache - Don't Panic original composer
LemonheadVGM - Scrappy Beat original composer
Echo Faust - Act Clear Jam original composer
RetriDoti - Sawnic sprites original artist
Kaching720 - Fefe sprite
AZURE STANELY HARDWARE - Newtrogic Panic shield sprites
Dolphman - Large Ring sprites
MiaCDI - Hyper Ring sprites
Square Enix - Einhander boss theme
------------------------------------------------------------------------------------------------
SMALL BUGS/ISSUES/ODDITIES I'VE OBSERVED BUT FIND TOO MINOR TO FIX/WILL BE FIXED AT A LATER TIME
------------------------------------------------------------------------------------------------
- Occasional "Too many sprites rendered" error, just click Cancel and the game continues to work as normal (hopefully).
- Effects have REALLY weird layering sometimes.
- A certain Easter Egg modifies Sonic's hitbox, causing some potential collision issues if you aren't careful. It's a 1/100 chance to encounter any easter egg in general so I literally don't care enough to fix it.
- Starting a zone via act select and not data/level select may bring up the aforementioned "Too many sprites rendered" error at some point in the zone for some strange reason. I have absolutely NO IDEA what causes this.
- Shock Death option may cause palette issues
- The zone music may start for a single frame then be stopped after a boss is defeated
- Sometimes you just randomly deflect a projectile for no reason???
------------------------------------------------------------------------------------------------
Follow the Newtrogic Panic twitter! (@NewtrogicPanic)